public class GameMind {

}
